# Laboratorio 03: Patrones Creacionales (Versión Simplificada)

---

## Caso de Estudio: Sistema de Juegos Básico

Una empresa desarrolladora necesita un sistema simple para crear juegos y gestionar configuraciones. El sistema debe manejar diferentes tipos de juegos y mantener configuraciones únicas.

---

## Preparación del Proyecto

1. Crea 3 paquetes:
   - `ejercicio01` - Factory Method
   - `ejercicio02` - Abstract Factory
   - `ejercicio03` - Singleton

---

## Ejercicio 1: Factory Method Pattern

### 1) Diagrama del Código Actual (Problemático):

```mermaid
classDiagram
    class GameCreator {
        +createGame(String type) Game
    }

    class Game {
        <<abstract>>
        #String name
        #String genre
        +start()* void
        +getInfo() String
    }

    class RPGGame {
        +start() void
    }

    class FPSGame {
        +start() void
    }

    GameCreator --> Game : creates
    Game <|-- RPGGame
    Game <|-- FPSGame

    note for GameCreator "❌ Usa switch/if-else
    para decidir qué crear"
```

### 2) Diagrama de la Solución (Factory Method):

```mermaid
classDiagram
    class GameFactory {
        <<abstract>>
        +createGame()* Game
        +playGame() void
    }

    class RPGFactory {
        +createGame() Game
    }

    class FPSFactory {
        +createGame() Game
    }

    class Game {
        <<abstract>>
        #String name
        +start()* void
        +getInfo() String
    }

    class RPGGame {
        +start() void
    }

    class FPSGame {
        +start() void
    }

    GameFactory <|-- RPGFactory
    GameFactory <|-- FPSFactory
    Game <|-- RPGGame
    Game <|-- FPSGame
    RPGFactory ..> RPGGame : creates
    FPSFactory ..> FPSGame : creates

    note for GameFactory "✅ Cada factory se especializa
    en crear un tipo específico"
```

#### **Implementa la solución creando:**

- `GameFactory` (abstracto) con `createGame()` abstracto y `playGame()` concreto
- `RPGFactory` y `FPSFactory` que extiendan `GameFactory`
- `PuzzleFactory` para demostrar extensibilidad

---

## Ejercicio 2: Abstract Factory Pattern

### 1) Diagrama del Código Actual (Problemático):

```mermaid
classDiagram
    class GameElementCreator {
        +createCharacter(String platform, String type) Character
        +createWeapon(String platform, String type) Weapon
    }

    class Character {
        <<abstract>>
        #String name
        #String platform
        #int health
        #Weapon weapon
        +equipWeapon(Weapon weapon) void
        +takeDamage(int damage) void
        +attack(Character target)* void
    }

    class Weapon {
        <<abstract>>
        #String name
        #String platform
        #int damage
        +getDamage() int
        +use()* void
    }

    class Warrior {
        +attack(Character target) void
    }

    class Enemy {
        +attack(Character target) void
    }

    class Sword {
        +use() void
    }

    class Claw {
        +use() void
    }

    GameElementCreator --> Character : creates
    GameElementCreator --> Weapon : creates
    Character <|-- Warrior
    Character <|-- Enemy
    Weapon <|-- Sword
    Weapon <|-- Claw
    Character o-- Weapon : has

    note for GameElementCreator "❌ No garantiza compatibilidad
    entre personajes y armas
    de una misma plataforma"
```

### 2) Diagrama de la Solución (Abstract Factory):

```mermaid
classDiagram
    class GameElementFactory {
        <<abstract>>
        +createWarrior()* Character
        +createEnemy()* Character
        +createSword()* Weapon
        +createClaw()* Weapon
    }

    class PCFactory {
        +createWarrior() Character
        +createEnemy() Character
        +createSword() Weapon
        +createClaw() Weapon
    }

    class MobileFactory {
        +createWarrior() Character
        +createEnemy() Character
        +createSword() Weapon
        +createClaw() Weapon
    }

    class Character {
        <<abstract>>
        #String name
        #String platform
        #int health
        #Weapon weapon
        +equipWeapon(Weapon weapon) void
        +takeDamage(int damage) void
        +attack(Character target)* void
    }

    class Weapon {
        <<abstract>>
        #String name
        #String platform
        #int damage
        +getDamage() int
        +use()* void
    }

    class PCWarrior {
        +attack(Character target) void
    }

    class MobileWarrior {
        +attack(Character target) void
    }

    class PCEnemy {
        +attack(Character target) void
    }

    class MobileEnemy {
        +attack(Character target) void
    }

    class PCSword {
        +use() void
    }

    class MobileSword {
        +use() void
    }

    class PCClaw {
        +use() void
    }

    class MobileClaw {
        +use() void
    }

    GameElementFactory <|-- PCFactory
    GameElementFactory <|-- MobileFactory
    Character <|-- PCWarrior
    Character <|-- MobileWarrior
    Character <|-- PCEnemy
    Character <|-- MobileEnemy
    Weapon <|-- PCSword
    Weapon <|-- MobileSword
    Weapon <|-- PCClaw
    Weapon <|-- MobileClaw

    PCFactory ..> PCWarrior : creates
    PCFactory ..> PCEnemy : creates
    PCFactory ..> PCSword : creates
    PCFactory ..> PCClaw : creates
    MobileFactory ..> MobileWarrior : creates
    MobileFactory ..> MobileEnemy : creates
    MobileFactory ..> MobileSword : creates
    MobileFactory ..> MobileClaw : creates
    
    Character o-- Weapon : has

    note for GameElementFactory "✅ Garantiza familias
    compatibles de objetos"
```

#### **Implementa la solución creando:**

- `GameElementFactory` (interface) con métodos de creación (`createWarrior`, `createEnemy`, `createSword`, `createClaw`).
- `PCFactory` y `MobileFactory` que implementen la interface.
- Clases específicas para cada variante: `PCWarrior`, `MobileWarrior`, `PCEnemy`, `MobileEnemy`, `PCSword`, `MobileSword`, `PCClaw`, `MobileClaw`.
- Cliente que use una factory para instanciar personajes y armas compatibles (ej. todo de PC o todo de Mobile), equipando a los personajes y demostrando un combate sin inconsistencias.

---

## Ejercicio 3: Singleton Pattern

### 1) Diagrama del Código Actual (Problemático):

```mermaid
classDiagram
    class GameConfig {
        -String databaseUrl
        -boolean debugMode
        -int maxPlayers
        +GameConfig()
        +getDatabaseUrl() String
        +setDebugMode(boolean) void
        +getMaxPlayers() int
    }

    class GameSession {
        -GameConfig config
        +GameSession()
        +startSession() void
    }

    class NetworkManager {
        -GameConfig config
        +NetworkManager()
        +connect() void
    }

    class DatabaseManager {
        -GameConfig config
        +DatabaseManager()
        +saveData() void
    }

    GameSession --> GameConfig : config = new GameConfig()
    NetworkManager --> GameConfig : config = new GameConfig()
    DatabaseManager --> GameConfig : config = new GameConfig()

    note for GameConfig "❌ Múltiples instancias
    con configuraciones diferentes"
```

### 2) Diagrama de la Solución (Singleton):

```mermaid
classDiagram
    class GameConfig {
        -static GameConfig instance
        -String databaseUrl
        -boolean debugMode
        -int maxPlayers
        -GameConfig()
        +static getInstance() GameConfig
        +getDatabaseUrl() String
        +setDebugMode(boolean) void
        +getMaxPlayers() int
    }

    class GameSession {
        +startSession() void
    }

    class NetworkManager {
        +connect() void
    }

    class DatabaseManager {
        +saveData() void
    }

    GameSession ..> GameConfig : getInstance()
    NetworkManager ..> GameConfig : getInstance()
    DatabaseManager ..> GameConfig : getInstance()

    note for GameConfig "✅ Una sola instancia
    compartida globalmente"
```

#### **Implementa la solución creando:**

- `GameConfig` singleton thread-safe con `getInstance()`
- `NetworkConfig` singleton usando enum
- Modificar los clientes para usar `getInstance()` en lugar de `new`

---

_Enfócate en entender por qué el código inicial es problemático antes de implementar la solución._
