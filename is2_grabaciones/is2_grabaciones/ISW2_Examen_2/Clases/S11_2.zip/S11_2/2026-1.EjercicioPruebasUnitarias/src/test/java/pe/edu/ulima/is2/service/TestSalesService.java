package pe.edu.ulima.is2.service;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import pe.edu.ulima.is2.model.VideoGame;
import pe.edu.ulima.is2.repository.VideoGameRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TestSalesService {
    private SalesService service;

    @Mock
    private VideoGameRepository videoGameRepository;

    @BeforeEach
    public void setUp(){
        service = new SalesService(videoGameRepository);
    }

    @Test
    // Crea la primera prueba unitaria
    public void testVideogameIdNoExiste(){
        when(videoGameRepository.findById(123l))
                .thenReturn(Optional.empty());

        // Recrear escenarios con bd es bien complicado
        assertThrows(RuntimeException.class,
                () -> service.processSale(123l, 1)
        );
    }

    @Test
    public void testCantidadMayorStock(){
        VideoGame vg = new VideoGame();
        vg.setStock(5);
        when(videoGameRepository.findById(12l)).
                thenReturn(Optional.of(vg));
        assertThrows(RuntimeException.class,
                () -> service.processSale(12l, 10)
        );
    }

    @Test
    @Disabled
    public void testVentaExistosa(){

    }

    @AfterAll
    public static void tearDown(){

    }
}
