package edu.ulima.galaxy;

import org.junit.jupiter.api.Test;

/**
 * Esqueleto de pruebas. El alumno debe:
 *  - Elegir UNO de los métodos analyzeA/analyzeB/analyzeC/analyzeD
 *    (según el análisis de complejidad ciclomatica) y probarlo.
 *  - NO usar mocks.
 */
public class GalaxySurveyorChosenMethodTest {

    @Test
    public void placeholder() {
        // TODO: Reemplazar con pruebas reales (y eliminar este placeholder).
        // Sugerencia: usar InMemoryNotifier para verificar notificaciones sin mocks.
        // Ejemplo:
        //   InMemoryNotifier notifier = new InMemoryNotifier();
        //   GalaxySurveyor surveyor = new GalaxySurveyor(new Stellar(), notifier);
        //   AnalysisResult r = surveyor.analyzeA(new Quadrant(10,20,30));
        //   assertNotNull(r);
    }
}
