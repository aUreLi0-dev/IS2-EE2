package pe.edu.ulima.is2.service;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import pe.edu.ulima.is2.model.VideoGame;
import pe.edu.ulima.is2.repository.VideoGameRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class TestSalesService {
    private SalesService service;

    @Mock
    private VideoGameRepository videoGameRepository;

    @BeforeEach
    public void setUp() {
        service = new SalesService(videoGameRepository);
    }

    @Test
    public void testVideogameIdNoExiste() {
        when(videoGameRepository.findById(123l))
                .thenReturn(Optional.empty());

        assertThrows(
                RuntimeException.class,
                () -> service.processSale(123l, 1)
        );
    }

    @Test
    public void testCantidadMayorStock() {
        VideoGame vg = new VideoGame();
        vg.setStock(5);
        when(videoGameRepository.findById(12l))
                .thenReturn(Optional.of(vg));
        assertThrows(
                RuntimeException.class,
                () -> service.processSale(12l, 10)
        );
    }

    @Test
    public void testVentaExitosa() {
        VideoGame vg = new VideoGame();
        vg.setPrice(20.0);
        vg.setStock(5);
        when(videoGameRepository.findById(12l))
                .thenReturn(Optional.of(vg));

        Double total = service.processSale(12l, 2);
        assertEquals(40, total );
        assertEquals(3, vg.getStock());
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("Terminaron pruebas unitarias");
    }

}
