package pe.edu.ulima.is2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class CalculadoraTest {
    private Calculadora calculadora;

    @BeforeEach
    public void setUp() {
        // Inicializacion
        calculadora = new Calculadora();
    }

    @Test
    public void testSuma() {
        int resEsperado = 10;

        int resObtenido = calculadora.sumar(6, 4);

        assertEquals(resEsperado, resObtenido);
    }

    @Test
    public void testResta() {
        int resEsperado = 2;

        int resObtenido = calculadora.restar(6, 4);

        assertEquals(resEsperado, resObtenido);
    }

    @Test
    public void testMultiplicacion() {
        int resEsperado = 24;

        int resObtenido = calculadora.multiplicar(6, 4);

        assertEquals(resEsperado, resObtenido);
    }

    @Test
    public void testDivision() {
        int resEsperado = 2;

        int resObtenido = calculadora.dividir(10, 5);

        assertEquals(resEsperado, resObtenido);
    }

    @Test
    public void testDivisionCero() {
        assertThrows(
                IllegalArgumentException.class,
                () -> {
                    int resObtenido = calculadora.dividir(10, 0);
                }
        );
    }

    @AfterEach
    public void tearDown() {
        // Limpieza
        System.out.println("Test terminado.");
    }
}
