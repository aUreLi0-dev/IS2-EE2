package pe.edu.ulima.is2;

import java.util.Locale;

public class Calculadora {

    public int sumar(int n1, int n2) {
        return n1 + n2;
    }

    public int restar(int n1, int n2){
        return n1 - n2;
    }

    public int multiplicar(int n1, int n2) {
        return n1 * n2;
    }

    public int dividir(int n1, int n2)  throws IllegalArgumentException{
        if (n2 == 0) {
            throw new IllegalArgumentException();
        }
        return n1 / n2;
    }

    public void metodoConError() {
        String texto = "Hola IS2";

        if (texto.equals("Hola IS2")) {
            System.out.println("Es igual");
        }


        if (texto != null) {
            System.out.println(texto.toUpperCase(Locale.getDefault()));
        }
    }

    static void main() {
        System.out.println("Esta sera la clase calculadora");
    }
}
