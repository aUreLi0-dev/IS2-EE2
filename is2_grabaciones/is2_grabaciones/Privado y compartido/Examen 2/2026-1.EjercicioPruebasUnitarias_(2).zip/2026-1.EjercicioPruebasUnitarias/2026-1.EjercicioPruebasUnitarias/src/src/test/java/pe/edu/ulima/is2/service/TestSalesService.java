package pe.edu.ulima.is2.service;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import pe.edu.ulima.is2.model.VideoGame;
import pe.edu.ulima.is2.repository.VideoGameRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class) // No olvidar esto
public class TestSalesService {
    private SalesService service;

    // Creamos el mock porque no nos interesa probar nada de repository
    @Mock
    private VideoGameRepository videoGameRepository;

    @BeforeEach
    // Al inicio de las pruebas
    public void setUp(){
        service = new SalesService(videoGameRepository);
    }

    /*
    @Test
    public void testVideogameIdNoExiste(){
        // Configuras el Mock para que cuando le llegue como argumento de entrada
        // del metodo findId el valor 123l -> siempre devuelva vacío
        when(videoGameRepository.findById(123l))
                .thenReturn(Optional.empty());

        assertThrows(
                RuntimeException.class,
                () -> service.processSale(123l, 1)
        );
    }
    */
    // Esto queda mejor quitando también lo que se colocó en SalesService.java !!
    @Test
    public void testVideogameIdNoExiste(){
        // Configuras el Mock para que cuando le llegue como argumento de entrada
        // del metodo findId el valor 123l -> siempre devuelva vacío
        when(videoGameRepository.findById(123l))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.processSale(123l, 1)
        );
        assertEquals("Game not found", ex.getMessage());
    }

    @Test
    public void testCantidadMayorStock(){
        // solo me importa stock
        VideoGame vg = new VideoGame();
        vg.setStock(5);

        when(videoGameRepository.findById(12l))
                .thenReturn(Optional.of(vg));

        assertThrows(
                RuntimeException.class,
                () -> service.processSale(12l,10)
        );
    }

    @Test
    public void testVentaExitosa(){
        VideoGame vg = new VideoGame();
        vg.setPrice(20.0);
        vg.setStock(5);

        when(videoGameRepository.findById(12l))
                .thenReturn(Optional.of(vg));
        Double total = service.processSale(12l,2);
        assertEquals(40, total);
        assertEquals(3, vg.getStock());
    }

    @Test
    public void testVentaCantidadIgualStock(){
        VideoGame vg = new VideoGame();
        vg.setPrice(20.0);
        vg.setStock(5);

        when(videoGameRepository.findById(12l))
                .thenReturn(Optional.of(vg));
        Double total = service.processSale(12l, 5); // cantidad == stock
        assertEquals(100.0, total);
        assertEquals(0, vg.getStock());
    }

    @AfterAll
    // Al final de cada caso de prueba o al final de todo
    public static void tearDown(){ // se pone static para que solo se ejecute una vez !!
        System.out.println("Terminaron las pruebas unitarias!");
    }

}
